import React from 'react'
import './Newcollection.css'

const Newcollection = () => {
  return (
    <div className='newcollection'>
      <h1>New Collections</h1>
      <hr></hr>
      <div className='collections'>
        
      </div>
    </div>
  )
}

export default Newcollection
