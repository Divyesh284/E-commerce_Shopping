import React, { useContext } from 'react'
import { ShopContext } from '../Context/Shopcontext'
import { useParams } from 'react-router-dom';


const Product = () => {

  const { name } = useParams();
  return (
    <div>
      
    </div>
  )
}

export default Product
