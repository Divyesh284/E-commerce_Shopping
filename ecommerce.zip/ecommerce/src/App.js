import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import Footer from './Components/Footer/Footer';
import Shop from './Pages/Shop';
import Cart from './Pages/Cart';
import { Provider } from 'react-redux';
import Store from './Store/Store';
import Category from './Pages/Category';
import About from './Pages/About';
import Contact from './Pages/Contact';
import Login from './Pages/Login';
import Singlepage from './Pages/Singlepage';

function App() {
  return (
    <div>

      <Provider store={Store}>
        <BrowserRouter>
          <Navbar/>

          <Routes>
            <Route path='/' element={<Shop/>}/>
            <Route path='/cart' element={<Cart/>}/>
            <Route path='/category' element={<Category/>}/>
            <Route path='/about' element={<About/>}/>
            <Route path='/contact' element={<Contact/>}/>
            <Route path='/login' element={<Login/>}/>
            <Route path='/product/:id' element={<Singlepage/>}/>

            
          </Routes>

        <Footer/>
        </BrowserRouter>
        </Provider>
    </div>
  );
}

export default App;
