let Testomonial = [
    {
      "id": 1,
      "name": "Emily Johnson",
      "location": "New York, USA",
      "rating": "⭐⭐⭐⭐",
      "feedback": "Absolutely love the products! Fast delivery, great quality, and excellent customer service. Will definitely order again."
    },
    {
      "id": 2,
      "name": "Ravi Mehta",
      "location": "Mumbai, India",
      "rating": "⭐⭐⭐",
      "feedback": "The user interface was smooth and easy to navigate. Found exactly what I was looking for and it arrived on time. Great experience!"
    },
    {
      "id": 3,
      "name": "Laura Kim",
      "location": "Seoul, South Korea",
      "rating": "⭐⭐⭐⭐⭐",
      "feedback": "Stylish and sustainable! I love that your store is environmentally conscious. Keep up the good work!"
    }
  ]

  export default Testomonial;