import p1_img from "./product_1.png";
import p2_img from "./product_2.png";
import p3_img from "./product_3.png";
import p4_img from "./product_4.png";
import p5_img from "./product_5.png";
import p6_img from "./product_6.png";
import p7_img from "./product_7.png";
import p8_img from "./product_8.png";
import p9_img from "./product_9.png";
import p10_img from "./product_10.png";
import p11_img from "./product_11.png";
import p12_img from "./product_12.png";
import p13_img from "./product_13.png";
import p14_img from "./product_14.png";
import p15_img from "./product_15.png";
import p16_img from "./product_16.png";
import p17_img from "./product_17.png";
import p18_img from "./product_18.png";
import p19_img from "./product_19.png";
import p20_img from "./product_20.png";
import p21_img from "./product_21.png";
import p22_img from "./product_22.png";
import p23_img from "./product_23.png";
import p24_img from "./product_24.png";
import p25_img from "./product_25.png";
import p26_img from "./product_26.png";
import p27_img from "./product_27.png";
import p28_img from "./product_28.png";
import p29_img from "./product_29.png";
import p30_img from "./product_30.png";
import p31_img from "./product_31.png";
import p32_img from "./product_32.png";
import p33_img from "./product_33.png";
import p34_img from "./product_34.png";
import p35_img from "./product_35.png";
import p36_img from "./product_36.png";

let all_product = [
  {
    id: 1,
    name: "Striped Flutter Sleeve Overlap Collar Peplum Hem Blouse",
    category: "women",
    image: p1_img,
    new_price: 50.0,
    old_price: 80.5,
    description: "A lightweight floral dress perfect for summer outings, crafted from breathable fabric with a flattering A-line cut."
  },
  {
    id: 2,
    name: "Floral Summer Dress",
    category: "women",
    image: p2_img,
    new_price: 85.0,
    old_price: 120.5,
    description: "Classic denim jacket with a tailored fit and metal button closure, ideal for layering in all seasons."
  },
  {
    id: 3,
    name: "High-Waisted Jeans",
    category: "women",
    image: p3_img,
    new_price: 60.0,
    old_price: 100.5,
    description:"Soft cotton crewneck T-shirt with a relaxed fit, versatile for any casual outfit."
  },
  {
    id: 4,
    name: "Denim Jacket",
    category: "women",
    image: p4_img,
    new_price: 100.0,
    old_price: 150.0,
    description:"Stretchable high-rise jeans that hug your curves, designed for both comfort and style."
  },
  {
    id: 5,
    name: "Oversized Sweater",
    category: "women",
    image: p5_img,
    new_price: 80.0,
    old_price: 91.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 6,
    name: "Crop Top Set",
    category: "women",
    image: p6_img,
    new_price: 76.0,
    old_price: 84.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 7,
    name: "Boho Maxi Skirt",
    category: "women",
    image: p7_img,
    new_price: 42.0,
    old_price: 49.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 8,
    name: "Ribbed Knit Dress",
    category: "women",
    image: p8_img,
    new_price: 52.0,
    old_price: 61.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."

  },
  {
    id: 9,
    name: "Linen Wide-Leg Pants",
    category: "women",
    image: p9_img,
    new_price: 47.0,
    old_price: 58.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 10,
    name: "Printed Wrap Blouse",
    category: "women",
    image: p10_img,
    new_price: 35.0,
    old_price: 41.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 11,
    name: "Pleated Midi Skirt",
    category: "women",
    image: p11_img,
    new_price: 59.0,
    old_price: 63.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 12,
    name: "Faux Leather Leggings",
    category: "women",
    image: p12_img,
    new_price: 58.0,
    old_price: 69.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 13,
    name: "Men Green Solid Zippered Full-Zip Slim Fit Bomber Jacket",
    category: "men",
    image: p13_img,
    new_price: 70.0,
    old_price: 75.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 14,
    name: "Slim Fit Jeans",
    category: "men",
    image: p14_img,
    new_price: 61.0,
    old_price: 68.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 15,
    name: "Leather Jacket",
    category: "men",
    image: p15_img,
    new_price: 74.0,
    old_price: 85.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 16,
    name: "Sports Hoodie",
    category: "men",
    image: p16_img,
    new_price: 64.0,
    old_price: 73.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 17,
    name: "Cotton Polo T-shirt",
    category: "men",
    image: p17_img,
    new_price: 80.0,
    old_price: 84.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 18,
    name: "Formal Suit",
    category: "men",
    image: p18_img,
    new_price: 59.0,
    old_price: 76.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 19,
    name: "Denim Jacket",
    category: "men",
    image: p19_img,
    new_price: 82.0,
    old_price: 94.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 20,
    name: "Checked Shirt",
    category: "men",
    image: p20_img,
    new_price: 49.0,
    old_price: 65.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 21,
    name: "V-Neck Sweater",
    category: "men",
    image: p21_img,
    new_price: 76.0,
    old_price: 98.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 22,
    name: "Casual Shorts",
    category: "men",
    image: p22_img,
    new_price: 81.0,
    old_price: 95.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 23,
    name: "Cargo Pants",
    category: "men",
    image: p23_img,
    new_price: 85.0,
    old_price: 100.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 24,
    name: "Wool Overcoat",
    category: "men",
    image: p24_img,
    new_price: 91.0,
    old_price: 110.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 25,
    name: "Boys Orange Colourblocked Hooded Sweatshirt",
    category: "kid",
    image: p25_img,
    new_price: 81.0,
    old_price: 89.0,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 26,
    name: "Classic Blue Denim Jacket",
    category: "kid",
    image: p26_img,
    new_price: 24.0,
    old_price: 36.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 27,
    name: "Striped Polo T-Shirt",
    category: "kid",
    image: p27_img,
    new_price: 40.0,
    old_price: 48.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 28,
    name: "Cartoon Printed Hoodie",
    category: "kid",
    image: p28_img,
    new_price: 62.0,
    old_price: 70.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 29,
    name: "Casual Khaki Shorts",
    category: "kid",
    image: p29_img,
    new_price: 71.0,
    old_price: 86.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 30,
    name: "Graphic Tee with Dinosaur Print",
    category: "kid",
    image: p30_img,
    new_price: 35.0,
    old_price: 51.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 31,
    name: "Boys Slim Fit Jeans",
    category: "kid",
    image: p31_img,
    new_price: 42.0,
    old_price: 67.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 32,
    name: "Soft Cotton Pajama Set",
    category: "kid",
    image: p32_img,
    new_price: 65.0,
    old_price: 94.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 33,
    name: "Checked Flannel Shirt",
    category: "kid",
    image: p33_img,
    new_price: 105.0,
    old_price: 130.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 34,
    name: "Raincoat with Hood",
    category: "kid",
    image: p34_img,
    new_price: 95.0,
    old_price: 108.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 35,
    name: "Navy Blue Jogger Pants",
    category: "kid",
    image: p35_img,
    new_price: 85.0,
    old_price: 120.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
  {
    id: 36,
    name: "Boys Cotton Blazer",
    category: "kid",
    image: p36_img,
    new_price: 49.0,
    old_price: 70.5,
    description:"Flowy and feminine maxi skirt with bohemian prints, perfect for weekend getaways."
  },
];

all_product = all_product.map((yd) => ({ ...yd, quantity: 1}))

export default all_product;
