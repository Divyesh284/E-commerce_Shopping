import React, { useState } from 'react'
import './Navbar.css'
import logo from '../Assets/logo.png'
import cart_icon from '../Assets/cart_icon.png'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'

const Navbar = () => {

    const [menu,setMenu] = useState("shop");
    let names = useSelector((state) => state.cart)
    let dispatch = useDispatch()

  return (
    <div className='navbar'>
      <div className='nav-logo'>
        <img src={logo} alt=''/>
        <p>Shopper</p>
      </div>
      <ul className='nav-menu'>
        <li onClick={()=>{setMenu("shop")}}><Link style={{textDecoration: 'none',color:' #626262'}} to='/'>Home</Link>{menu==="shop"?<hr></hr>:<></>}</li>
        <li onClick={()=>{setMenu("mens")}}><Link style={{textDecoration: 'none',color:' #626262'}} to='/category'>Category</Link>{menu==="mens"?<hr></hr>:<></>}</li>
        <li onClick={()=>{setMenu("womens")}}><Link style={{textDecoration: 'none',color:' #626262'}} to='/about'>About</Link>{menu==="womens"?<hr></hr>:<></>}</li>
        <li onClick={()=>{setMenu("kids")}}><Link style={{textDecoration: 'none',color:' #626262'}} to='/contact'>Contact</Link>{menu==="kids"?<hr></hr>:<></>}</li>
      </ul>
      <div className='nav-login-cart'>
       <Link to='/login'> <button>Login</button></Link>
        <Link to='/cart'><img src={cart_icon} alt=''/></Link>
        <div className='nav-cart-court'>
          {names.length}
        </div>
      </div>
    </div>
  )
}

export default Navbar
