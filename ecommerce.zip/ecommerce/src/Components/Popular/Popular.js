import React, { useState } from 'react'
import './Popular.css'
import data_product from '../Assets/data'
import { useDispatch, useSelector } from 'react-redux';
import { add } from '../../Store/Cartslice';
import { Link } from 'react-router-dom';


const Popular = () => {
  let [demos,setDemos] = useState(data_product);

  let NAMES = useSelector((state)=>state.cart);
  let dispatch = useDispatch();

  let ADDTOCART = (yd) => {
    // dispatch(add(yd)
    let abcc = NAMES.find((ss) => ss.id === yd.id);
    if (!abcc) {
      dispatch(add(yd));
    } else {
      alert("ALLready added...!");
    }
  };
  return (
    <div className='popular'>
      <h1>Popular In Women</h1>
      <hr></hr>
      <div className='popular-item' style={{
        marginTop:30,
        display: "grid",
        gridTemplateColumns: "320px 320px 320px 320px",
        justifyContent: "center",
        textAlign: "center",
        gap: 60,
      }}>
        {data_product.map((yd) => {
          return (
            <div className="product-card">
              <Link to={`/product/${yd.id}`} style={{textDecoration:"none"}}>
              <img src={yd.image} alt="Product" className="product-image" />
              <div className="product-details">
                <h3 className="product-title">{yd.name}</h3>
                <div className='product-prices' style={{display:"flex",gap:15,justifyContent:"center"}}>
                  <p className="product-price">${yd.new_price}</p>
                  <p className="product-price" style={{ color: '#7d7c7c' }}>$<del>{yd.old_price}</del></p>

                </div>
                
                
              </div>
              </Link>
              <button className="add-to-cart" onClick={() => ADDTOCART(yd)}>Add to Cart</button>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default Popular




