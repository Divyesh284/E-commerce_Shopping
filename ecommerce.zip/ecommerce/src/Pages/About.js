import React from 'react'
import './Css/About.css'
import Testomonial from '../Components/Assets/Tesimonial'
import Newsletter from '../Components/NewsLetter/Newsletter'

const About = () => {
    return (
        <div>
            <section className="hero-banner">
                <h1>About Our Store</h1>
                <p>Driven by passion, built for you.</p>
            </section>
            <section className="story">
                <h2>Our Story</h2>
                <p>
                    Founded in 2020, our store began with a vision to make high-quality
                    fashion accessible to everyone. Today, we're proud to serve over 20,000
                    happy customers worldwide. We believe in ethical sourcing, customer-first
                    service, and beautiful design.
                </p>
            </section>
            <section className="stats">
                <div className="stat">
                    <h3>50K+</h3>
                    <p>Orders Delivered</p>
                </div>
                <div className="stat">
                    <h3>20K+</h3>
                    <p>Happy Customers</p>
                </div>
                <div className="stat">
                    <h3>100+</h3>
                    <p>Products</p>
                </div>
            </section>
            <section className="team">
                <h2>Meet the Team</h2>
                <div className='team-data'>
                {Testomonial.map((yd) => {
                    return(
                        <div class="testimonial-container">
                        <div class="testimonial-card">
                          <div class="testimonial-header">
                            <h3>{yd.name}</h3>
                            <span class="location"><i class="fas fa-map-marker-alt"></i> {yd.location}</span>
                          </div>
                          <div class="rating">
                            {yd.rating}
                          </div>
                          <p class="feedback">
                            {yd.feedback}
                          </p>
                        </div>
                      </div>
                    )
                })}
                </div>
            </section>
           
            <section className="cta">
                <h2>Ready to Shop?</h2>
                <a href="/" className="cta-button">
                    Explore Products
                </a>
            </section>
            <Newsletter/>
        </div>
    )
}

export default About
