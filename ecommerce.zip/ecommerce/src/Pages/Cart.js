import React from 'react'
import './Css/Cart.css'
import { useDispatch, useSelector } from 'react-redux'
import { decrement, increment, remove } from '../Store/Cartslice';

const Cart = () => {
    let NAMES = useSelector((state) => state.cart);
    let dispatch = useDispatch();

    let REMOVETOCART = (ydId) => {
        dispatch(remove(ydId));
    }
    let INCREMENT = (ydId) => {
        dispatch(increment(ydId))
    }
    let DECREMENT = (ydId) => {
        dispatch(decrement(ydId))
    }
    let total = NAMES.reduce((acc, item) => {
        let subtotal = item.new_price * item.quantity;
        let totalWithExtras = (subtotal + 3) * 1.0804;
        return acc + totalWithExtras;
    }, 0).toFixed(2);
    return (
        
        <div>
            {NAMES.length === 0 ? <h1>Your cart is empty</h1> : ""}
            {NAMES.map((yd) => {

                let finalprice = yd.new_price * yd.quantity
                
                return (
                    <div>
                        <div className="cart-card">
                            <img src={yd.image} alt="cart" className="cart-image" />

                            <div className="cart-info">
                                <div className="cart-title">{yd.name}</div>
                                <div className="cart-price">${yd.new_price}</div>
                            </div>

                            <div className="quantity-control">
                                <button onClick={() => DECREMENT(yd.id)}>-</button>
                                <h1>{yd.quantity}</h1>
                                <button onClick={() => INCREMENT(yd.id)}>+</button>
                            </div>

                            <div className="total-price">${finalprice}</div>
                            <button
                                style={{
                                    width: "100%",
                                    padding: 20,
                                    fontWeight: 800,
                                    fontSize: 20,
                                }}
                                className='remove-to-cart'
                                onClick={() => REMOVETOCART(yd.id)}
                            >
                                REMOVE TO CART
                            </button>
                        </div>

                    </div>
                );
            })}
            
            <div class="summary-card">
            <h2>Order Summary</h2>
                <div class="summary-row total">
                <span>Total Price (incl. $3 fee & 8.04% tax):<br/></span>
                    <span>${total}</span>
                </div>
            </div>
            <button className="add-to-cart" style={{height:38,marginTop:42 }}><a href='/' style={{textDecoration:"none",color:"white"}}>Go Back To Home</a></button>
        </div>
    )
}

export default Cart
