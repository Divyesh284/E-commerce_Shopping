import React, { useState } from 'react'
import './Css/Category.css'
import all_product from '../Components/Assets/all_product'
import { useDispatch, useSelector } from 'react-redux'
import { add } from '../Store/Cartslice'
import { Link } from 'react-router-dom'

const Category = () => {

    let [demos, setDemos] = useState(all_product)
    const [menu, setMenu] = useState("all");
    let [serachh, setSearchh] = useState("");

    let NAMES = useSelector((state) => state.cart);
    let dispatch = useDispatch();

    let BUTTONSS = (aa) => {
        let abccc = all_product.filter((dd) => dd.category === aa);
        setDemos(abccc);
    };
    let ADDTOCART = (nn) => {
        let abcc = NAMES.find((ss) => ss.id === nn.id);
        if (!abcc) {
            dispatch(add(nn));
        } else {
            alert("ALLready added...!");
        }
    };

    let SEARCHHHH = (e) => {
        setSearchh(e.target.value);

        let xyz = all_product.filter((ss) => {
            return ss.name?.toLowerCase().includes(e.target.value.toLowerCase());
        });
        setDemos(xyz);
    };
    return (
        <div className='category'>
            <div className="sidebar">
                <h2 style={{ textAlign: "center" }}>Categories</h2>
                <button
                    className='category-btn'
                    onClick={() => {
                        setDemos(all_product);
                        setMenu("all");
                    }}
                    style={menu === "all" ? { background: "#2a9d8f", color: "white", borderRadius: 18 } : {}}
                >
                    All
                </button>

                <button
                    className='category-btn'
                    onClick={() => {
                        BUTTONSS("men");
                        setMenu("men");
                    }}
                    style={menu === "men" ? { background: "#2a9d8f", color: "white", borderRadius: 18 } : {}}
                >
                    Men
                </button>

                <button
                    className='category-btn'
                    onClick={() => {
                        BUTTONSS("women");
                        setMenu("women");
                    }}
                    style={menu === "women" ? { background: "#2a9d8f", color: "white", borderRadius: 18 } : {}}
                >
                    Women
                </button>

                <button
                    className='category-btn'
                    onClick={() => {
                        BUTTONSS("kid");
                        setMenu("kid");
                    }}
                    style={menu === "kid" ? { background: "#2a9d8f", color: "white", borderRadius: 18 } : {}}
                >
                    Kids
                </button>

                <input
                    type="search"
                    placeholder="search here.."
                    value={serachh}
                    onChange={SEARCHHHH}
                    style={{ padding: "16px 45px" }}
                />


            </div>
            <div style={{
                marginTop: 30,
                marginLeft: 100,
                display: "grid",
                gridTemplateColumns: "320px 320px 320px 320px",
                justifyContent: "center",
                textAlign: "center",
                gap: 25,

            }}>
                {demos.map((yd) => {
                    return (
                        <div className="product-card">
                            <Link to={`/product/${yd.id}`} style={{textDecoration:"none"}}>

                            <img src={yd.image} alt="Product" className="product-image" />
                            <div className="product-details">
                                <h3 className="product-title">{yd.name}</h3>
                                <div className='product-prices' style={{ display: "flex", gap: 15, justifyContent: "center" }}>
                                    <p className="product-price">${yd.new_price}</p>
                                    <p className="product-price" style={{ color: '#7d7c7c' }}>$<del>{yd.old_price}</del></p>

                                </div>

                                
                            </div>
                            </Link>
                            <button className="add-to-cart" onClick={() => ADDTOCART(yd)}>Add to Cart</button>
                        </div>
                    )
                })}
            </div>


        </div>
    )
}

export default Category
