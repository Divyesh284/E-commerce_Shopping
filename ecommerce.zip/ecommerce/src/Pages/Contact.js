import React from 'react'
import './Css/Contact.css'

const Contact = () => {
    return (
        <div>
            <section className="contact-section">
                <h1>Contact Us</h1>
                <div className="contact-container">
                    <div className="contact-info">
                        <div className="info-box">
                            <i className="fas fa-envelope" />
                            <p>support@shopnow.com</p>
                        </div>
                        <div className="info-box">
                            <i className="fas fa-phone" />
                            <p>+1 800 123 456</p>
                        </div>
                        <div className="info-box">
                            <i className="fas fa-map-marker-alt" />
                            <p>123 Main St, New York, NY</p>
                        </div>
                    </div>
                    <form className="contact-form">
                        <input type="text" placeholder="Full Name" required="" />
                        <input type="email" placeholder="Email Address" required="" />
                        <input type="text" placeholder="Subject" required="" />
                        <textarea
                            rows={5}
                            placeholder="Your Message..."
                            required=""
                            defaultValue={""}
                        />
                        <button type="submit">Send Message</button>
                    </form>
                </div>
                <div className="map-container">
                    <iframe
                        src="https://maps.google.com/maps?q=new%20york&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        frameBorder={0}
                        allowFullScreen=""
                        loading="lazy"
                    />
                </div>
            </section>


        </div>
    )
}

export default Contact
