import React, { useState } from 'react';
import './Css/Login.css';

const Login = () => {
  const [isSignup, setIsSignup] = useState(false);

  return (
    <div className="containers">
      <div className={`form-container ${isSignup ? 'shift' : ''}`}>
        <div className="form login-form">
          <h2>Login</h2>
          <form>
            <div className="input-box">
              <i className="fas fa-envelope" />
              <input type="email" placeholder="Email" required />
            </div>
            <div className="input-box">
              <i className="fas fa-lock" />
              <input type="password" placeholder="Password" required />
            </div>
            <button type="submit">Login</button>
            <p className="switch">
              Don't have an account?{' '}
              <span onClick={() => setIsSignup(true)}>Sign up</span>
            </p>
          </form>
        </div>
        <div className="form signup-form">
          <h2>Sign Up</h2>
          <form>
            <div className="input-box">
              <i className="fas fa-user" />
              <input type="text" placeholder="Username" required />
            </div>
            <div className="input-box">
              <i className="fas fa-envelope" />
              <input type="email" placeholder="Email" required />
            </div>
            <div className="input-box">
              <i className="fas fa-lock" />
              <input type="password" placeholder="Password" required />
            </div>
            <button type="submit">Register</button>
            <p className="switch">
              Already have an account?{' '}
              <span onClick={() => setIsSignup(false)}>Login</span>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
