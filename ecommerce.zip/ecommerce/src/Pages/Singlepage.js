import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import all_product from '../Components/Assets/all_product';
import new_collections from '../Components/Assets/new_collections';
import data_product from '../Components/Assets/data';
import './Css/Singlepage.css';
import { useDispatch, useSelector } from 'react-redux';
import { add } from '../Store/Cartslice';

const Singlepage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const cartItems = useSelector((state) => state.cart);

    const allProducts = [...all_product, ...new_collections, ...data_product];
    const [product, setProduct] = useState(null);

    useEffect(() => {
        const found = allProducts.find((p) => p.id === Number(id));
        setProduct(found);
    }, [id]);

    const ADDTOCART = (item) => {
        const exists = cartItems.find((p) => p.id === item.id);
        if (!exists) {
            dispatch(add(item));
        } else {
            alert("Already added!");
        }
    };

    if (!product) return <div>Product not found</div>;

    // Get related products
    const relatedProducts = allProducts
        .filter((p) => p.id !== product.id && p.category === product.category)
        .slice(0, 4);

    if (relatedProducts.length < 4) {
        const extras = allProducts
            .filter((p) => p.id !== product.id && p.category !== product.category)
            .slice(0, 4 - relatedProducts.length);
        relatedProducts.push(...extras);
    }

    return (
        <div className="single-product-container">
            <button onClick={() => navigate(-1)} className="back-button">← Back</button>

            <div className="single-product-card">
                <div className="image-container">
                    <img src={product.image || 'https://via.placeholder.com/300'} alt={product.name} className="single-product-image" />
                    {product.status && (
                        <span className={`badge ${product.status.toLowerCase().replace(' ', '-')}`}>
                            {product.status}
                        </span>
                    )}
                </div>
                <div className="single-product-details">
                    <h2>{product.name}</h2>
                    <p>{product.description || "No description available."}</p>
                    <p><strong>Price:</strong> ${product.new_price}</p>
                    <button className="add-to-cart" onClick={() => ADDTOCART(product)}>Add to Cart</button>
                </div>
            </div>

            <div className="related-products">
                <h3>You May Also Like</h3>
                <div className="related-grid">
                    {relatedProducts.map((item) => (
                        <div key={item.id} className="related-card">
                            <Link to={`/${item.id}`} style={{textDecoration:"none", color:"black"}}>
                                <div className="image-container">
                                    <img src={item.image} alt={item.name} />
                                    {item.status && (
                                        <span className={`badge ${item.status.toLowerCase().replace(' ', '-')}`}>
                                            {item.status}
                                        </span>
                                    )}
                                </div>
                                <h4>{item.name}</h4>
                            </Link>
                            <p>${item.new_price}</p>
                            <button onClick={() => ADDTOCART(item)}>Add to Cart</button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Singlepage;
